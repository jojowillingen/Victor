const uiWrapper = document.querySelector('.ui-wrapper')

let followElements = []
let followElementsPositions = []
let constructorCb = null

export default class UI {
  constructor (callback) {
    constructorCb = callback
    
    followElements = uiWrapper.querySelectorAll('[data-follow]')
    followElements.forEach(element => followElementsPositions.push(element.getBoundingClientRect()))

    const burgerButton = uiWrapper.querySelector('.burger')
    const paging = uiWrapper.querySelector('.fixed-content-paging')
    const menuPaging = uiWrapper.querySelector('.menu-list')

    const footerYear = uiWrapper.querySelector('.footer-copy__date')
    footerYear.innerHTML = `© ${new Date().getFullYear()}`
    
    burgerButton.addEventListener('click', this.toggleMenu, false)
    paging.addEventListener('click', this.onPagingClick.bind(this), false)
    menuPaging.addEventListener('click', this.onMenuPagingClick.bind(this), false)
  }

  moveEvent (e) {
    this.buttonMoveAnimation(e)
  }

  buttonMoveAnimation (e) {
    const mouseLeft = e.clientX
    const mouseTop = e.clientY
    followElements.forEach((element, index) => {
      const elementPositions = followElementsPositions[index]
      // If cursor is close to the button element then move the button closer to the cursor;
      if (mouseLeft > elementPositions.left - 100 && mouseLeft < elementPositions.right + 100 && 
          mouseTop > elementPositions.top - 100 && mouseTop < elementPositions.bottom + 100) {
        const moveX = (elementPositions.left - mouseLeft) / 10
        const moveY = (elementPositions.top - mouseTop) / 10
        element.style.transform = `translate3d(${-moveX}px, ${-moveY}px, 0)`
        element.style.transition = ''
      } else {
        element.style.transform = `translate3d(0, 0, 0)`
        element.style.transition = 'transform 500ms ease'
      }
    })
  }

  toggleMenu () {
    uiWrapper.classList.toggle('menu-opened')
    document.querySelector('.burger').classList.toggle('burger--active')
  }

  moveScene (direction) {
    this.checkContentVisibility(direction)
  }

  onMenuPagingClick (e) {
    this.toggleMenu()
    this.onPagingClick(e)
  }

  onPagingClick (e) {
    const datasetPage = +e.target.dataset.page
    if (datasetPage >= 0) {
      constructorCb().onPagingClick(datasetPage)
    }
  }

  checkContentVisibility (direction) {
    const contentSections = uiWrapper.querySelectorAll('[data-page]')
    const animateSection = section => {
      // Add different class depending on scroll direction.
      if (direction === 'down')  {
        section.classList.add('section--hidden')
        section.classList.remove('section--hidden-reverse')
      } else {
        section.classList.add('section--hidden-reverse')
        section.classList.remove('section--hidden')
      }

      if (+section.dataset.page === constructorCb().getCurrentPage()) {
        section.style.display = 'flex'
        const removeClass = () => section.classList.remove('section--hidden', 'section--hidden-reverse')
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(removeClass)
        })
      }
    }

    // For each section first hide them all then show active.
    contentSections.forEach(section => {
      // Set low opacity on section that is leaving.
      // Transition is set in (main.css).
      section.style.opacity = '0'
      // Set timeout for the transition to end.
      setTimeout(() => {
        // Remove style tag with opacity and display property.
        section.removeAttribute('style')
        animateSection(section)
      }, 300)
    })
  }
}
